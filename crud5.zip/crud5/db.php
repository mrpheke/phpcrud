<?php
$con = mysqli_connect('localhost','root','','crud5');
if($con){
	
}else{
	echo "Tidak terkoneksi";
}

?>