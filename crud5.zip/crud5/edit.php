<?php
include('db.php');
$id = $_GET['id'];

if(isset($_POST['submit']))
{
	$nama = $_POST['nama'];
	$nip = $_POST['nip'];
	$unit = $_POST['unit'];
	$jabatan = $_POST['jabatan'];
	$alamat = $_POST['alamat'];
	$kontak  = $_POST['kontak'];
	
	$msg = "";
	$image = $_FILES['image']['name'];
	$target = "images/".basename($image);

	if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
  		$msg = "Foto berhasil diupload!";
  	}else{
  		$msg = "Foto gagal terupload!";
  	}

	$update = "UPDATE dataku SET nama='$nama', nip = '$nip', unit = '$unit', jabatan = '$jabatan', alamat = '$alamat', kontak = '$kontak', image = '$image' WHERE id=$id ";
	$run_update = mysqli_query($con,$update);

	if($run_update){
		header('location:index.php');
	}else{
		echo "Data tidak terupdate!";
	}
}

?>
