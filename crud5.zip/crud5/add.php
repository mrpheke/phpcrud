<?php

include('db.php');

if(isset($_POST['submit'])){
	$id = $_POST['id'];
	$nama = $_POST['nama'];
	$nip = $_POST['nip'];
	$unit = $_POST['unit'];
	$jabatan = $_POST['jabatan'];
	$alamat = $_POST['alamat'];
	$kontak = $_POST['kontak'];


	//image upload

	$msg = "";
	$image = $_FILES['image']['name'];
	$target = "images/".basename($image);

	if (move_uploaded_file($_FILES['image']['tmp_name'], $target)) {
  		$msg = "Foto berhasil diupload!";
  	}else{
  		$msg = "Foto gagal terupload!";
  	}

  	$insert_data = "INSERT INTO dataku (id,nama,nip,unit,jabatan,alamat,kontak,image) VALUES ('$id','$nama','$nip','$unit','$jabatan','$alamat','$kontak','$image')";
  	$run_data = mysqli_query($con,$insert_data);

  	if($run_data){
  		header('location:index.php');
  	}else{
  		echo "Data gagal terinput!";
  	}

}

?>